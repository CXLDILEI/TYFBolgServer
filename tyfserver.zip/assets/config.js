module.exports ={
    MONGOOSE:{
        AUTHOR:"test:test123456",
        DATABASE:"tyf"
    }
}