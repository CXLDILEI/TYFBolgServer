const express = require('express'),
    router = express.Router()

router.post('/pictureZip',(req,res)=>{
    console.log(req.body)
})
module.exports=router;














